import React, { useState } from 'react';
import axios from 'axios';


export const TodoComponent = (props) => {
  const cleantodo = {
    isbn: "",
    name: "",
    title: "",
    price:""
  }
  const [todo, settodo] = useState(cleantodo);
  const [isbnError, setisbnError] = useState({});
  const [nameError, setnameError] = useState({});
  const [titleError, settitleError] = useState({});
  const [priceError, setpriceError] = useState({});

  const todoData = JSON.stringify({...todo});
  const customConfig = {
        headers: {
        'Content-Type': 'application/json'
        }
    };



  const fetchBackend = e => {
    const result = axios.post('http://localhost:8082/todo', todoData, customConfig)
    .then((response)=>{
        settodo(response.data.value);

    });
    e.preventDefault();
}

  const handleOnSubmit = (e) => {
    e.preventDefault();
    const isValid = formValidation();
    if (isValid) {
        settodo(cleantodo);
      alert("Form is valid");
    }
  }

  const formValidation = () => {
    const isbnErr = {};
    const nameErr= {};
    const titleErr = {};
    const priceErr = {};

    let isValid = true;

    if (todo.isbn.trim().length < 2) {
      isbnErr.isbnShort = "isbn is too short"
      isValid = false;
    }
    if (todo.name.trim().length > 12) {
      nameErr.nameShort = "name name is too long"
      isValid = false;
    }
    if (todo.title.trim().length < 5) {
      titleErr.titleShort = "Title is too short"
      isValid = false;
    }
    var price = new RegExp([0-9]);
    if (!price.test(todo.price.trim())) {
          priceErr.priceShouldBeNumber = "price should be uumber"
          isValid = false;
    }

    setisbnError(isbnErr);
    setnameError(nameErr);
    settitleError(titleErr);
    setpriceError(priceErr);

    return isValid;
  }

  const handleFieldChange = (e) => {
    settodo({ ...todo, [e.target.name]: e.target.value });
  }


  let addtodo = (
    <div>
      <form onSubmit={handleOnSubmit}>
        <h3>Enter todo Detaile</h3>
        <div>
          isbn
          <input
            type="text"
            placeholder="isbn"
            name="isbn"
            value={todo.isbn}
            onChange={handleFieldChange} />
          {Object.keys(isbnError).map((key) => {
            return <div style={{ color: "red" }}>{isbnError[key]}</div>
          })}
        </div>

        <div>
        Name
          <input
            type="text"
            placeholder="name name"
            name="name"
            value={todo.name}
            onChange={handleFieldChange} />

          {Object.keys(nameError).map((key) => {
            return <div style={{ color: "red" }}>{nameError[key]}</div>
          })}
        </div>
        <div>
        Title
          <input
            type="text"
            placeholder="title"
            name="title"
            value={todo.title}
            onChange={handleFieldChange} />
          {Object.keys(titleError).map((key) => {
            return <div style={{ color: "red" }}>{titleError[key]}</div>
          })}
        </div>
        <div>
        Price
          <input
            type="text"
            placeholder="price"
            name="price"
            value={todo.price}
            onChange={handleFieldChange} />
          {Object.keys(priceError).map((key) => {
            return <div style={{ color: "red" }}>{priceError[key]}</div>
          })}
        </div>
        <button type="submit">Save</button>
      </form>
    </div>

  );
  return addtodo;
}


