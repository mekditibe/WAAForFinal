import classes from './Counter.module.css';
import { useSelector, useDispatch } from 'react-redux';

const Calculatores = () => {

  const DataInput = {
    num1: "",
    num2: ""
  }
  const [data, setDataInput] = useState(DataInput);

  const dispatch = useDispatch();
  const result = useSelector(state => state.result);

  const addHandler = () => {
    result=num1+num2;
  }

  const subHandler = () => {
    result=num1-num2;
  }

  const multHandler = () => {
    result=num1*num2;
  }


  return (
    <div>
      <h1>Redux Calculator</h1>
      <div>
        <input type="number" placeholder="num1" name="num1" value={num1}>Number 1</input>
        <input type="number" placeholder="num2" name="num2" value={num2}>Number 2</input>
        <input type="number">Result: {result}</input>

      </div>
      <div>
        <button onClick={addHandler}>Add</button>
        <button onClick={subHandler}>SUB</button>
        <button onClick={multHandler}>MUL</button>
      </div>
    </div>
  );
};

export default Calculatores;
