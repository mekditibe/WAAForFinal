import {Calculator} from './components/Calculator';
import {Todo} from './components/Todo';



function App() {
  return (
    <div>
      <div>Part1</div>

      <Calculator />
      <div>Part2</div>
      <Todo />

    </div>
)}

export default App;
