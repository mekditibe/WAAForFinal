package bank.web;

import bank.service.AccountDTO;
import bank.service.AccountService;
import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AccountMutation implements GraphQLMutationResolver {

    @Autowired
    private AccountService accountService;

    public AccountDTO createAccount(final int accountnumber, final String accountHolder) {
        AccountDTO accountDTO = new AccountDTO(accountnumber, accountHolder);
        accountService.add(accountDTO);
        return accountDTO;
    }
    public int deposit(final int accountnumber, final Double amount, final String desription) {
        accountService.deposit(accountnumber ,amount);
        return accountnumber;
    }

    public int withdraw(final int accountnumber, final Double amount, final String desription) {
        accountService.withdraw(accountnumber ,amount);
        return accountnumber;
    }

}
