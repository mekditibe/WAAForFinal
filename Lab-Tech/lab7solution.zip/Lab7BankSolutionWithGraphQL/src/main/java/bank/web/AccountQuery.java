package bank.web;

import bank.domain.Account;
import bank.service.AccountDTO;
import bank.service.AccountService;
import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class AccountQuery implements GraphQLQueryResolver {

    @Autowired
    private AccountService accountService;

    public List<AccountDTO> getAccounts() {
        return accountService.findAll().stream().collect(Collectors.toList());
    }

    public Optional<AccountDTO> getAccount(final int accountNumber) {
        return Optional.of(accountService.findByAccountNumber(accountNumber));
    }
}
